// Create a new panel
chrome.devtools.panels.create("Caffeine",
			      null,
			      "panel.html",
			      null
			     )

