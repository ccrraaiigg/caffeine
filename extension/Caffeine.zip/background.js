// The Caffeine Helper extension manages the Chrome debugger for the
// Caffeine in-browser IDE.
//
// Copyright (c) 2017 Craig Latta, d/b/a Black Page Digital.
// All Rights Reserved.

var tabs = {}
var version = "1.0"
var tether

// Speak with webpage-based Caffeine IDEs.
chrome.runtime.onConnectExternal.addListener(
  function(port) {
    tether = port

    tether.onMessage.addListener(
      function(message) {
	switch(message.selector) {
	case "tabs":
	  chrome.tabs.query(
	    {title: "*"},
	    function(result){
	      respondToMessageWith(message, result)})
	  break

	case "myID":
	  respondToMessageWith(message, tether.sender.tab.id)
	  break

	case "attach":
	  var debuggeeId = {tabId: message.parameters[0]}

	  chrome.debugger.attach(
	    debuggeeId,
	    version,
	    onAttach.bind(null, debuggeeId))
	  respondToMessageWith(message, true)
	  break

	case "detach":
	  var debuggeeId = {tabId: message.parameters[0]}

	  chrome.debugger.detach(
	    debuggeeId,
	    onDetach.bind(null, debuggeeId))
	  respondToMessageWith(message, true)
	  break

	default:
	  if (Object.keys(message.parameters[1]).length > 0) {
	    chrome.debugger.sendCommand(
	      {tabId: message.parameters[0]},
	      // API command name
	      message.selector,
	      // API command parameters
	      message.parameters[1],
	      function(result) {
		if (chrome.runtime.lastError) {
		  respondToMessageWith(message, chrome.runtime.lastError)}
		else {
		  respondToMessageWith(message, result)}})}
	  else {
	    chrome.debugger.sendCommand(
	      {tabId: message.parameters[0]},
	      // API command name
	      message.selector,
	      function(result) {
		if (chrome.runtime.lastError) {
		  respondToMessageWith(message, chrome.runtime.lastError)}
		else {
		  respondToMessageWith(message, result)}})}
	}})})

chrome.debugger.onEvent.addListener(onEvent)
chrome.debugger.onDetach.addListener(onDetach)

// Handle clicks on the extension icon.
chrome.browserAction.onClicked.addListener(
  function(tab) {
    var tabId = tab.id
    var debuggeeId = {tabId: tabId}

    // If present, tabs[tabId] can be "attaching" while waiting for
    // attachment, or "attached" after attachment.
    if (tabs[tabId] === "attaching")
      return

    if (!tabs[tabId]) {
      tabs[tabId] = "attaching"
      chrome.debugger.attach(
        debuggeeId,
	version,
	onAttach.bind(null, debuggeeId))}
    else if (tabs[tabId]) {
      tabs[tabId] = "detaching"
      chrome.debugger.detach(
        debuggeeId,
	onDetach.bind(null, debuggeeId))}
  })

function respondToMessageWith(message, result) {
  tether.postMessage({
    promiseID: message.promiseID,
    result: result})}

function onAttach(debuggeeId) {
  // A debugger has attached to the tab indicated by
  // debuggeeId. Change the extension icon, to indicate the
  // attachment.
    
  if (chrome.runtime.lastError) {
    alert(chrome.runtime.lastError.message)
    return}

  var tabId = debuggeeId.tabId

  chrome.browserAction.setIcon({
    tabId: tabId,
    path: "caffeineRed16.png"})

  chrome.browserAction.setTitle({
    tabId: tabId,
    title: "Debugging with Caffeine"})

  tabs[tabId] = "attached"
  chrome.debugger.sendCommand(debuggeeId, "Debugger.enable")
}

function onEvent(debuggeeId, method, parameters) {
  // Forward all DevTools events to Caffeine, except for script parses
  // that have no URL (e.g., when the SqueakJS JIT translates a
  // method).
  
  if (!(((method === "Debugger.scriptParsed") && (parameters.url === ""))))
    tether.postMessage({
      tabID: debuggeeId.tabId,
      method: method,
      params: parameters})
}

function onDetach(debuggeeId) {
  var tabId = debuggeeId.tabId
  delete tabs[tabId]
  chrome.browserAction.setIcon({tabId: tabId, path: "caffeine16.png"})
  chrome.browserAction.setTitle({tabId: tabId, title: "Debug with Caffeine"})
}
